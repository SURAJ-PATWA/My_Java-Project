package tech.codingclub.helix.entity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import tech.codingclub.helix.global.HttpUrlConnectionExample;

public class WikipediaDownloader {
    //private static TaskManager taskmanager=new TaskManager(20);
    private String keyword;


    public WikipediaDownloader(String keyword) {

        this.keyword = keyword;
    }

    public WikiResult getResult() {
        if (this.keyword == null || this.keyword.length() == 0) {
            return null;
        }
// step 1
        this.keyword = this.keyword.trim().replaceAll("[ ]+", "_");  // trim remove stasrting and ending space remove
        // step 2
        String wikiUrl = getWikipediaUrlForQuery(this.keyword);
        String response = "";
        String imageUrl = null;
        try {
//            //step 3
            String wikipediaResponseHTML = HttpUrlConnectionExample.sendGet(wikiUrl);                   //HttpURLConnectionExample.sendGet(wikiUrl);
            //System.out.print(wikipediaResponseHTML);

            //step 4
            Document document = (Document) Jsoup.parse(wikipediaResponseHTML, "https://en.wikipedia.org");
            ///fElements mainElement= document.;
            Elements childElements = document.body().select(".mw-parser-output > *");  // it is select  the  child  element
            int state = 0;

            for (Element childElemet : childElements) {
                if (state == 0) {
                    if (childElemet.tagName().equals("table")) {
                        state = 1;
                    }
                } else if (state == 1)
                    if (childElemet.tagName().equals("p")) {
                        state = 2;

                        response = childElemet.text();
                        break;
                    }
            }
            try {
                imageUrl = document.body().select(".infobox img").get(0).attr("src");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        WikiResult wikiResult = new WikiResult(this.keyword, response, imageUrl);
        //push result into database

        return wikiResult;
    }


    private String getWikipediaUrlForQuery(String cleanKeyword) {
        return "https://en.wikipedia.org/wiki/"+cleanKeyword;
    }
}  